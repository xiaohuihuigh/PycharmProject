# -*- coding:utf-8 -*-
# 用途： 用于一些一次性数据采集及临时数据采集任务的爬虫代码备份
# 创建日期: 18-9-10 下午1:04

import time

if __name__ == "__main__":
    start_t = time.time()

    pass

    print("use time: %s" % (time.time() - start_t))
