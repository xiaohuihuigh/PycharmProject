# -*- coding:utf-8 -*-
# 用途： 测试模块
# 创建日期: 18-8-28 下午5:38

import time

if __name__ == "__main__":
    start_t = time.time()

    pass

    print("use time: %s" % (time.time() - start_t))
