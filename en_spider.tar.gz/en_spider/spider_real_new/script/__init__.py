# -*- coding:utf-8 -*-
# 用途： 一些脚本工具
# 创建日期: 18-9-3 下午3:42

import time

if __name__ == "__main__":
    start_t = time.time()

    pass

    print("use time: %s" % (time.time() - start_t))
