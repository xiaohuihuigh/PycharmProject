#!/usr/bin/env bash
tar -zcvf htmls_$$.tar.gz htmls
cd htmls
rm -rf *.html