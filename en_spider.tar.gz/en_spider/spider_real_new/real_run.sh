#!/usr/bin/env bash
source ~/env/spider/bin/activate && python -m manage >> ~/log/run.log 2>&1 &
