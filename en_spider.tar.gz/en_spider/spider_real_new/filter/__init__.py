# -*- coding:utf-8 -*-
# 用途： 一些过滤规则
# 创建日期: 18-9-4 下午6:28

import time


if __name__ == "__main__":
    start_t = time.time()

    pass

    print("use time: %s" % (time.time() - start_t))
