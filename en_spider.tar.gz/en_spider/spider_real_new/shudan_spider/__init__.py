# -*- coding:utf-8 -*-
# 用途： 用来存储分析师需要的单个爬虫
# 创建日期: 18-9-10 下午12:55

import time




if __name__ == "__main__":
    start_t = time.time()

    pass

    print("use time: %s" % (time.time() - start_t))
