# -*- coding:utf-8 -*-
# 用途： 新闻页面爬虫，用于采集旧的百度采集的url中的新闻
# 创建日期: 18-8-25 下午6:44

import time

if __name__ == "__main__":
    start_t = time.time()

    pass

    print("use time: %s" % (time.time() - start_t))
